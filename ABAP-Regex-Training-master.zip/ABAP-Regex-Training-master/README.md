ABAP Regular Expressions Training

Installation:
- Create the classes
- Create the programs
- Create a functiongroup named zregextraining (use source from saplzregextraining.abap)
- Add a function named z_rt_taskview (use source from lzregextrainingu01.abap)
- Add all includes to the functiongroup (use source from lz*.abap)
- Add the screen number 0001 to the functiongroup (screen 0001.txt)
- Add the gui status 1 and gui title 1 to the functiongroup (gui_status_1.txt, gui_title_1.txt)
- Activate all
- Run program zregextraining and have fun!
